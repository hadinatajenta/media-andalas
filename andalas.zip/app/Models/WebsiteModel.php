<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WebsiteModel extends Model
{
    use HasFactory;

    protected $table = 'website';
protected $fillable = [
    'nama_website',
    'deskripsi_website',
    'keyword_website',
    'robot_txt', // Pastikan ini sama dengan nama kolom di database
    'favicon',
    'updated_at',
];

}
