<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\IklanModel;
use App\Models\PengiklanModel;
use Carbon\Carbon;

class IklanController extends Controller
{
public function index(Request $request)
{
    $order = $request->query('order');
    $status = $request->query('status');
    // Mengambil parameter 'status' dari query string.

    $iklans = IklanModel::all();

    if ($order === 'asc') {
        $pengiklanQuery = PengiklanModel::orderBy('tanggal_masuk', 'asc');
    } else {
        $pengiklanQuery = PengiklanModel::orderBy('tanggal_masuk', 'desc');
    }

    // Jika status di-set, tambahkan ke query
    if ($status && $status !== 'all') {
        $pengiklanQuery->where('status', $status);
    }

    $pengiklan = $pengiklanQuery->get();

    $currentYear = $request->input('year', date('Y'));

    $monthlyIncomeStats = PengiklanModel::getMonthlyIncomeByYear($currentYear);

    return view('admin.management-iklan.iklan', compact('iklans', 'pengiklan', 'monthlyIncomeStats', 'currentYear', 'order', 'status'));
}


    
    
}
