<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BeritaModel;
use App\Models\PengiklanModel;
use App\Models\WebsiteModel;

class HomePageController extends Controller
{
    public function index(){
        //Mendapatkan data website
        $website = WebsiteModel::first();

        //Menampilkan  Featured News pada halaman welcome
        $berita = BeritaModel::where('featured', '1')
        ->orderBy('created_at', 'desc')
        ->limit(6)
        ->get();
        
        //menampilkan berita terbaru
        $latestnews = BeritaModel::where('status', 'Published')
        ->orderBy('created_at', 'desc')
        ->limit(13)
        ->get();
        
        //Menampilkan iklan vertikal yang berstatus berjalan
        $iklan = PengiklanModel::whereHas('iklan', function($query) {
            $query->where('id_iklan', '1');
        })->where('status', 'berjalan')->first();

        return view('welcome', compact('berita','latestnews','iklan','website'));
    }
}
