

<?php $__env->startSection('title', 'Manajemen Author'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card">
                    <img src="/images/klee.png" class="card-img-top" alt="team member 1">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->name); ?></h5>
                        <p class="card-text">Deskripsi singkat mengenai anggota 1.</p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/author.blade.php ENDPATH**/ ?>