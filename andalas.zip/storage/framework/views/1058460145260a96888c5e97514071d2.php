

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <a href="<?php echo e(route('admin.dashboard', ['status' => 'published'])); ?>" style="text-decoration: none; color:black;" class="notif card p-2">
                <div class="card-header d-flex align-items-center">
                    <i class="bx bx-check-circle p-2 bx-sm ceklis" ></i>
                    &nbsp;
                    <p class="p-0 m-0" style="font-weight: 500">Berita dipublikasikan</p>
                </div>
                <div class="card-body">
                    <h2><?php echo e($dipublikasikan); ?> </h2>
                    <div class="d-flex align-items-center mb-0 pb-0">
                        <p class="p-0 m-0">Total berita di publikasikan</p>
                    </div>
                </div>
            </a>
        </div>
        <div class=" col-md-4">
            <a href="<?php echo e(route('admin.dashboard', ['status' => 'waiting'])); ?>" style="text-decoration: none; color:black;" class="notif card p-2">
                <div class="card-header d-flex align-items-center">
                    <i class="bx bx-time-five p-2 bx-sm waktu" style=";"></i>
                    &nbsp;
                    <p class="p-0 m-0" style="font-weight: 500">Berita menunggu</p>
                </div>
                <div class="card-body">
                    <h2><?php echo e($jumlahBeritaMenunggu); ?> </h2>
                    <div class="d-flex align-items-center mb-0 pb-0">
                        <p class="p-0 m-0">Total berita menunggu</p>
                    </div>
                </div>
            </a>
        </div>
        <div class=" col-md-4">
            <div class=" card p-2">
                <div class="card-header d-flex align-items-center">
                    <i class="bx bx-folder-open p-2 bx-sm kategori"></i>
                    &nbsp;
                    <p class="p-0 m-0" style="font-weight: 500">Total kategori</p>
                </div>
                <div class="card-body">
                    <h2><?php echo e($totalkategori); ?> </h2>
                    <div class="d-flex align-items-center mb-0 pb-0">
                        <p class="p-0 m-0" >Total seluruh kategori</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row my-4" >
        <div class="col">
            <div class="card p-2">
                <div class=" d-flex align-items-center justify-content-between card-header ">
                    <div class="judul">
                        <h4>Daftar berita</h4>
                        <p class="p-0 m-0">Seluruh berita dengan semua status </p>
                    </div>
                    <form action="<?php echo e(route('admin.dashboard')); ?>" method="GET" class="d-flex my-2 my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Cari Berita" aria-label="Cari Berita" name="search">
                        <button class="btn btn-outline-success my-2 my-sm-0" style="height: calc(1.5em + .75rem + 2px);" type="submit"><i class='bx bx-search-alt-2'></i></button>
                    </form>
                    <a href="<?php echo e(route('admin.create')); ?>" class="btn" style="background-color: #5a7af9; color:white; font-size:12px;">+ Tambah berita</a>

                </div> 
                <div class="card-body">
                    <div class="table-responsive" style="background-color: #fff; border-radius:10px;">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php elseif(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th class="th" scope="col">Judul Berita</th>
                                    <th class="th" scope="col">Kategori</th>
                                    <th class="th" scope="col" style="text-align: center">Featured</th>
                                    <th class="th" scope="col">Status</th>
                                    <th class="th" scope="col">Author</th>
                                    <th class="th" scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($berita->isEmpty()): ?>
                                    <tr>
                                        <td colspan="6" style="text-align:center">Tidak ada berita menunggu</td>
                                    </tr>
                                <?php else: ?>
                                <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle" style="max-width: 250px;  overflow: hidden; text-overflow: ellipsis;"><?php echo e($item->judul_berita); ?></td>
                                    <td class="align-middle"><?php echo e($item->kategori->nama_kategori ?? 'N/A'); ?></td>
                                    <td class="align-middle" style="text-align: center">
                                        <?php if($item->status == 'Published'): ?>
                                            <?php if($item->featured): ?>
                                                <a href="<?php echo e(route('admin.removeFeatured', $item->id_berita)); ?>" class="btn"><i class='bx bx-x bx-sm x'></i></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('admin.makeFeatured', $item->id_berita)); ?>" class="btn"><i class='bx bx-check bx-sm check'></i></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>

                                    <td class="align-middle">
                                        <div class="p-2 d-flex align-items-center" style="border:1px solid #eaeaea; color:black; border-radius:5px; font-size:12px;">
                                            <i class='bx bxs-circle' 
                                            style="color:
                                            <?php if($item->status == 'Published'): ?>
                                                #22b07d
                                            <?php elseif($item->status == 'waiting'): ?>
                                                #FFC107
                                            <?php elseif($item->status == 'ditolak'): ?>
                                                #db1731
                                            <?php elseif($item->status == 'draft'): ?>
                                                #007bff
                                            <?php endif; ?>;">
                                            </i>
                                            &nbsp;
                                            <p class="m-0"><?php echo e($item->status); ?></p>
                                        </div>
                                    </td>
                                    <td class="align-middle"><?php echo e($item->author->name); ?></td>
                                    <td class="align-middle">
                                        <a href="<?php echo e(route('admin.berita.detail', $item->id_berita)); ?>" class="btn edit-kategori" >  
                                            <i class='bx bxs-pencil'></i> &nbsp; Edit
                                        </a>
                                        <form id="delete-form-<?php echo e($item->id_berita); ?>" action="<?php echo e(route('admin.destroy', ['id' => $item->id_berita])); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                        <a href="<?php echo e(route('admin.destroy',$item->id_berita)); ?>" class="btn hapus-kategori" onclick="
                                                event.preventDefault();
                                                if(confirm('Anda yakin ingin menghapus berita ini?')) {
                                                    document.getElementById('delete-form-<?php echo e($item->id_berita); ?>').submit();
                                                }">
                                                <i class='bx bx-trash' ></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Pagination -->
    <div class="d-flex justify-content-center mt-2">
        <?php echo e($berita->links('vendor.pagination.bootstrap-4')); ?>

    </div>
    <!-- End Pagination -->
</div>
<script>
    setTimeout(function(){
        $('.alert').fadeOut('slow');
    }, 5000); // <-- waktu dalam milidetik
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>