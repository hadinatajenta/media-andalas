<!DOCTYPE html>
<html lang="id-ID" itemscope="itemscope" itemtype="http://schema.org/WebPage">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    
    <?php echo SEO::generate(); ?>

        <link rel="icon" type="image/x-icon" href="<?php echo e(asset($website->favicon)); ?>">


    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-2X714VSNX2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-2X714VSNX2');
</script>
    <!-- Favicon -->
    <link href="/images/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="/css/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <?php if (isset($component)) { $__componentOriginal7f27d4f21ff184c2d29c20efafbd7387 = $component; } ?>
<?php $component = App\View\Components\Topbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f27d4f21ff184c2d29c20efafbd7387)): ?>
<?php $component = $__componentOriginal7f27d4f21ff184c2d29c20efafbd7387; ?>
<?php unset($__componentOriginal7f27d4f21ff184c2d29c20efafbd7387); ?>
<?php endif; ?>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
    <!-- Navbar End -->

    <!-- Main News Slider Start -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-7 px-0">
                <!-- Main Carousel Start -->
                <div class="owl-carousel main-carousel position-relative">
                    <div class="position-relative overflow-hidden" style="height: 500px;">
                        <img class="img-fluid h-100" src="/images/news-800x500-1.jpg" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Business</a>
                                <a class="text-white" href="">Jan 01, 2045</a>
                            </div>
                            <a class="h2 m-0 text-white text-uppercase font-weight-bold" href="">Lorem ipsum dolor sit amet elit. Proin vitae porta diam...</a>
                        </div>
                    </div>
                    <div class="position-relative overflow-hidden" style="height: 500px;">
                        <img class="img-fluid h-100" src="/images/news-800x500-2.jpg" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Business</a>
                                <a class="text-white" href="">Jan 01, 2045</a>
                            </div>
                            <a class="h2 m-0 text-white text-uppercase font-weight-bold" href="">Lorem ipsum dolor sit amet elit. Proin vitae porta diam...</a>
                        </div>
                    </div>
                    <div class="position-relative overflow-hidden" style="height: 500px;">
                        <img class="img-fluid h-100" src="/images/news-800x500-3.jpg" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Business</a>
                                <a class="text-white" href="">Jan 01, 2045</a>
                            </div>
                            <a class="h2 m-0 text-white text-uppercase font-weight-bold" href="">Lorem ipsum dolor sit amet elit. Proin vitae porta diam...</a>
                        </div>
                    </div>
                </div>
                <!-- Main Carousel End -->
            </div>
            <div class="col-lg-5 px-0">
                <!-- Sub Carousel Start -->
                <div class="row mx-0">
                    <div class="col-md-6 px-0">
                        <div class="position-relative overflow-hidden" style="height: 250px;">
                            <img class="img-fluid w-100 h-100" src="/images/news-700x435-1.jpg" style="object-fit: cover;">
                            <div class="overlay">
                                <div class="mb-2">
                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                        href="">Business</a>
                                    <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                                </div>
                                <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Lorem ipsum dolor sit amet elit...</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 px-0">
                        <div class="position-relative overflow-hidden" style="height: 250px;">
                            <img class="img-fluid w-100 h-100" src="/images/news-700x435-2.jpg" style="object-fit: cover;">
                            <div class="overlay">
                                <div class="mb-2">
                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                        href="">Business</a>
                                    <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                                </div>
                                <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Lorem ipsum dolor sit amet elit...</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 px-0">
                        <div class="position-relative overflow-hidden" style="height: 250px;">
                            <img class="img-fluid w-100 h-100" src="/images/news-700x435-3.jpg" style="object-fit: cover;">
                            <div class="overlay">
                                <div class="mb-2">
                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                        href="">Business</a>
                                    <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                                </div>
                                <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Lorem ipsum dolor sit amet elit...</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 px-0">
                        <div class="position-relative overflow-hidden" style="height: 250px;">
                            <img class="img-fluid w-100 h-100" src="/images/news-700x435-4.jpg" style="object-fit: cover;">
                            <div class="overlay">
                                <div class="mb-2">
                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                        href="">Business</a>
                                    <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                                </div>
                                <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Lorem ipsum dolor sit amet elit...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Sub Carousel End -->
            </div>
        </div>
    </div>
    <!-- Main News Slider End -->


    <!-- Breaking News Start -->
    <div class="container-fluid bg-dark py-3 mb-3">
        <div class="container">
            <div class="row align-items-center bg-dark">
                <div class="col-12">
                    <div class="d-flex justify-content-between">
                        <div class="bg-primary text-dark text-center font-weight-medium py-2" style="width: 170px;">Breaking News</div>
                        <div class="owl-carousel tranding-carousel position-relative d-inline-flex align-items-center ml-3"
                            style="width: calc(100% - 170px); padding-right: 90px;">
                            <div class="text-truncate"><a class="text-white text-uppercase font-weight-semi-bold" href="">Lorem ipsum dolor sit amet elit. Proin interdum lacus eget ante tincidunt, sed faucibus nisl sodales</a></div>
                            <div class="text-truncate"><a class="text-white text-uppercase font-weight-semi-bold" href="">Lorem ipsum dolor sit amet elit. Proin interdum lacus eget ante tincidunt, sed faucibus nisl sodales</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breaking News End -->

    <!-- Featured News Slider Start -->
    <div class="container-fluid pt-5 mb-3">
        <div class="container">
            <div class="section-title">
                <h4 class="m-0 text-uppercase font-weight-bold">Featured News</h4>
            </div>
            <div class="owl-carousel news-carousel carousel-item-4 position-relative">
                <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-relative overflow-hidden" style="height: 300px;">
                    <img class="img-fluid h-100"  alt="<?php echo e($item->judul_berita); ?>"
                        <?php if($item->gambar_berita): ?>
                            src="<?php echo e(Storage::url('berita/' . $item->gambar_berita)); ?>"
                        <?php else: ?>
                            src="<?php echo e(Storage::url('berita/tidak-ada-gambar.jpg')); ?>"
                        <?php endif; ?> style="object-fit: cover;"
                    >
                    <div class="overlay">
                        <div class="mb-2">
                            <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                href=""><?php echo e($item->kategori->nama_kategori ?? 'Tidak ada Kategori'); ?> </a>
                             <?php
                                \Carbon\Carbon::setLocale('id');
                            ?>
                            <a class="text-white" href=""><small><?php echo e($item->updated_at->translatedFormat('d F Y')); ?></small></a>
                        </div>
                        <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="<?php echo e(route('single.show', $item->slug)); ?>"><?php echo e($item->judul_berita); ?></a>
                    </div>
                </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
    <!-- Featured News Slider End -->


    <!-- News With Sidebar Start -->
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-title">
                                <h4 class="m-0 text-uppercase font-weight-bold">Latest News</h4>
                                <a class="text-secondary font-weight-medium text-decoration-none" href="">View All</a>
                            </div>
                        </div>                            
                        <?php
                            $breakAt = 4; 
                            $secondCardCount = 0; // to hold the count of second style cards
                            $secondCardLimit = 4;
                            $thirdCardCount = 0; // to hold the count of third style cards
                            $thirdCardLimit = 1; // display only one large card
                            $smallCardCount = 0; // to hold the count of small style cards
                            $smallCardLimit = 4; // display four small cards
                        ?>
                         <!--Iklan 728x90-->
                        <div class="col-lg-12 mb-3">
                            <?php if($iklan): ?>
                                <a href="<?php echo e($iklan->website); ?>"><img class="img-fluid w-100" src="/uploads/<?php echo e($iklan->gambar_iklan); ?>" alt="<?php echo e($iklan->website); ?>"></a>
                            <?php else: ?>
                                <p>No Ads Available</p>
                            <?php endif; ?>
                        </div>
                        <!--End Iklan-->
                        <?php $__currentLoopData = $latestnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($index < $breakAt): ?>
                                <!--2 Card Besar-->
                                <div class="col-lg-6">
                                    <div class="position-relative mb-3">
                                        <!--Gambar berita-->
                                        <img class="img-fluid w-100" alt="<?php echo e($item->judul_berita); ?>"
                                        <?php if($item->gambar_berita): ?>
                                            src="<?php echo e(Storage::url('berita/' . $item->gambar_berita)); ?>"
                                        <?php else: ?>
                                            src="<?php echo e(Storage::url('berita/tidak-ada-gambar.jpg')); ?>"
                                        <?php endif; ?>
                                        style="width: 364px; height: 226px; object-fit: cover;" >

                                        <!-- Grup info berita -->
                                        <div class="bg-white border border-top-0 p-4">
                                            <div class="mb-2">
                                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href=""><?php echo e($item->kategori->nama_kategori); ?></a>
                                                <a class="text-body" href=""><small><?php echo e($item->created_at->format ('j F Y')); ?></small></a>
                                            </div>
                                            <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href="/single/<?php echo e($item->slug); ?>"><?php echo e(Str::limit($item->judul_berita, 31, '...')); ?></a>
                                            <p class="m-0"><?php echo e(Str::limit($item->deskripsi_berita,96,'...')); ?></p>
                                        </div>
                                        <!--Grup info author-->
                                        <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
                                            <!-- nama author-->
                                            <div class="d-flex align-items-center">
                                                <small>Penulis : <?php echo e($item->author->name); ?></small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            <?php elseif($secondCardCount < $secondCardLimit): ?>
                                <!--4 Card Kecil-->
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                        <img alt="<?php echo e($item->judul_berita); ?>" class="img-fluid"  style="height:110px; width: 110px; object-fit: cover;"
                                            <?php if($item->gambar_berita): ?>
                                                src="<?php echo e(Storage::url('berita/' . $item->gambar_berita)); ?>"
                                            <?php else: ?>
                                                src="<?php echo e(Storage::url('berita/tidak-ada-gambar.jpg')); ?>"
                                            <?php endif; ?>
                                        alt="<?php echo e($item->judul_berita); ?>">
                                        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                            <div class="mb-2">
                                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href=""><?php echo e($item->kategori->nama_kategori); ?></a>
                                                <a class="text-body" href=""><small><?php echo e($item->created_at->format('j F Y')); ?></small></a>
                                            </div>
                                            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="/single/<?php echo e($item->slug); ?>"><?php echo e(Str::limit ($item->judul_berita,50,'...')); ?></a>
                                        </div>
                                    </div>                                   
                                </div>
                                <?php
                                    $secondCardCount++;
                                ?>
                            
                            <?php else: ?>
                                <?php if($thirdCardCount < $thirdCardLimit): ?>
                                    <div class="col-lg-12">
                                        <div class="row news-lg mx-0 mb-3">
                                            <div class="col-md-6 h-100 px-0">
                                                <img alt="<?php echo e($item->judul_berita); ?>" class="img-fluid h-100" alt="<?php echo e($item->judul_berita); ?>"
                                                <?php if($item->gambar_berita): ?>
                                                    src="<?php echo e(Storage::url('berita/' . $item->gambar_berita)); ?>"
                                                <?php else: ?>
                                                    src="<?php echo e(Storage::url('berita/tidak-ada-gambar.jpg')); ?>"
                                                <?php endif; ?>
                                                style="width: 372px; height:350px; object-fit: cover;">
                                            </div>
                                            <div class="col-md-6 d-flex flex-column border bg-white h-100 px-0">
                                                <div class="mt-auto p-4">
                                                    <div class="mb-2">
                                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                                            href=""><?php echo e($item->kategori ? $item->kategori->nama_kategori : 'null'); ?></a>
                                                        <a class="text-body" href=""><?php echo e($item->created_at->format('j F Y')); ?></small></a>
                                                    </div>
                                                    <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href=""><?php echo e(Str::limit($item->judul_berita, 50, '...')); ?></a>
                                                    <p class="m-0"><?php echo e(Str::limit($item->konten_berita, 150, '...')); ?></p>
                                                </div>
                                                <div class="d-flex justify-content-between bg-white border-top mt-auto p-4">
                                                    <div class="d-flex align-items-center">
                                                         <small><?php echo e($item->author->name); ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        $thirdCardCount++;
                                    ?>
                                <?php elseif($smallCardCount < $smallCardLimit): ?>
                                    <div class="col-lg-6">
                                        <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                            <img alt="<?php echo e($item->judul_berita); ?>" class="img-fluid"  style="height:110px; width: 110px; object-fit: cover;"
                                                <?php if($item->gambar_berita): ?>
                                                    src="<?php echo e(Storage::url('berita/' . $item->gambar_berita)); ?>"
                                                <?php else: ?>
                                                    src="<?php echo e(Storage::url('berita/tidak-ada-gambar.jpg')); ?>"
                                                <?php endif; ?>
                                            alt="<?php echo e($item->judul_berita); ?>">
                                            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                                <div class="mb-2">
                                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href=""><?php echo e($item->kategori->nama_kategori); ?></a>
                                                    <a class="text-body" href=""><small><?php echo e($item->created_at->format('j F Y')); ?></small></a>
                                                </div>
                                                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="/single/<?php echo e($item->slug); ?>"><?php echo e(Str::limit ($item->judul_berita,50,'...')); ?></a>
                                            </div>
                                        </div>                                   
                                    </div>
                                    <?php
                                        $smallCardCount++;
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                    </div>
                </div>
                <!--Sidebar-->       
                <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
                <!--End sidebar-->
            </div>
        </div>
    </div>
    <!-- News With Sidebar End -->


    <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>



    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="/css/lib/easing/easing.min.js"></script>
    <script src="/css/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="/js/main.js"></script>
    
</body>

</html><?php /**PATH E:\code\tugas-akhir\resources\views/welcome.blade.php ENDPATH**/ ?>