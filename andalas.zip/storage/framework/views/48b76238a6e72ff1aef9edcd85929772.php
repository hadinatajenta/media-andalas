<div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-title">
                                <h4 class="m-0 text-uppercase font-weight-bold">Latest News</h4>
                                <a class="text-secondary font-weight-medium text-decoration-none" href="">View All</a>
                            </div>
                        </div>                            
                        <?php
                            $breakAt = 4; 
                            $secondCardCount = 0; // to hold the count of second style cards
                            $secondCardLimit = 2;
                            $thirdCardCount = 0; // to hold the count of third style cards
                            $thirdCardLimit = 1; // display only one large card
                            $smallCardCount = 0; // to hold the count of small style cards
                            $smallCardLimit = 4; // display four small cards
                        ?>
                         <!--Iklan 728x90-->
                        <div class="col-lg-12 mb-3">
                            <?php if($iklan): ?>
                                <a href="<?php echo e($iklan->website); ?>"><img class="img-fluid w-100" src="/uploads/<?php echo e($iklan->gambar_iklan); ?>" alt="<?php echo e($iklan->website); ?>"></a>
                            <?php else: ?>
                                <p>No Ads Available</p>
                            <?php endif; ?>
                        </div>
                        <!--End Iklan-->
                        <?php $__currentLoopData = $latestnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($index < $breakAt): ?>
                                <!--2 Card Besar-->
                                <div class="col-lg-6">
                                    <div class="position-relative mb-3">
                                        <!--Gambar berita-->
                                        <img class="img-fluid w-100" alt="<?php echo e($item->judul_berita); ?>"
                                        <?php if($item->gambar_berita): ?>
                                            src="<?php echo e(Storage::url('berita/' . $item->gambar_berita)); ?>"
                                        <?php else: ?>
                                            src="<?php echo e(Storage::url('berita/tidak-ada-gambar.jpg')); ?>"
                                        <?php endif; ?>
                                        style="width: 364px; height: 226px; object-fit: cover;" >

                                        <!-- Grup info berita -->
                                        <div class="bg-white border border-top-0 p-4">
                                            <div class="mb-2">
                                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href=""><?php echo e($item->kategori->nama_kategori); ?></a>
                                                <a class="text-body" href=""><small><?php echo e($item->created_at->format ('j F Y')); ?></small></a>
                                            </div>
                                            <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href="/single/<?php echo e($item->slug); ?>"><?php echo e(Str::limit($item->judul_berita, 31, '...')); ?></a>
                                            <p class="m-0"><?php echo e(Str::limit($item->deskripsi_berita,96,'...')); ?></p>
                                        </div>
                                        <!--Grup info author-->
                                        <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
                                            <!-- nama author-->
                                            <div class="d-flex align-items-center">
                                                <small>Penulis : <?php echo e($item->author->name); ?></small>
                                            </div>
                                            <!--View-->
                                            <div class="d-flex align-items-center">
                                                <small class="ml-3"><i class="far fa-eye mr-2"></i>12345</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            <?php elseif($secondCardCount < $secondCardLimit): ?>
                            
                                <!--4 Card Kecil-->
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                        <img alt="<?php echo e($item->judul_berita); ?>" class="img-fluid" src="/images/news-110x110-1.jpg" alt="">
                                        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                            <div class="mb-2">
                                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href=""><?php echo e($item->kategori->nama_kategori); ?></a>
                                                <a class="text-body" href=""><small><?php echo e($item->created_at->format('j F Y')); ?></small></a>
                                            </div>
                                            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href=""><?php echo e(Str::limit ($item->judul_berita,50,'...')); ?></a>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                        <img alt="<?php echo e($item->judul_berita); ?>" class="img-fluid" src="/images/news-110x110-2.jpg" alt="">
                                        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                            <div class="mb-2">
                                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href=""><?php echo e($item->kategori->nama_kategori); ?></a>
                                                <a class="text-body" href=""><small><?php echo e($item->created_at->format('j F Y')); ?></small></a>
                                            </div>
                                            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href=""><?php echo e(Str::limit($item->judul_berita,50,'...')); ?></a>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    $secondCardCount++;
                                ?>
                            
                            <?php else: ?>
                                <?php if($thirdCardCount < $thirdCardLimit): ?>
                                    <div class="col-lg-12">
                                        <div class="row news-lg mx-0 mb-3">
                                            <div class="col-md-6 h-100 px-0">
                                                <img alt="<?php echo e($item->judul_berita); ?>" class="img-fluid h-100" src="<?php echo e($item->image_path); ?>" alt="<?php echo empty($item->image_path) ? 'Tidak ada gambar' : '' ?>" style="object-fit: cover;">
                                            </div>
                                            <div class="col-md-6 d-flex flex-column border bg-white h-100 px-0">
                                                <div class="mt-auto p-4">
                                                    <div class="mb-2">
                                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                                            href=""><?php echo e($item->kategori ? $item->kategori->nama_kategori : 'null'); ?></a>
                                                        <a class="text-body" href=""><?php echo e($item->created_at->format('j F Y')); ?></small></a>
                                                    </div>
                                                    <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href=""><?php echo e(Str::limit($item->judul_berita, 50, '...')); ?></a>
                                                    <p class="m-0"><?php echo e(Str::limit($item->konten_berita, 150, '...')); ?></p>
                                                </div>
                                                <div class="d-flex justify-content-between bg-white border-top mt-auto p-4">
                                                    <div class="d-flex align-items-center">
                                                        <img class="rounded-circle mr-2" src="<?php echo e($item->author_image); ?>" width="25" height="25" alt="">
                                                        <small><?php echo e($item->author_name); ?></small>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <small class="ml-3"><i class="far fa-eye mr-2"></i><?php echo e($item->views_count); ?></small>
                                                        <small class="ml-3"><i class="far fa-comment mr-2"></i><?php echo e($item->comments_count); ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        $thirdCardCount++;
                                    ?>
                                <?php elseif($smallCardCount < $smallCardLimit): ?>
                                    <div class="col-lg-6">
                                        <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                            <img alt="<?php echo e($item->judul_berita); ?>" class="img-fluid" src="<?php echo e($item->image_path); ?>" alt="<?php echo empty($item->image_path) ? 'Tidak ada gambar' : '' ?>">

                                            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                                <div class="mb-2">
                                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href=""><?php echo e($item->kategori ? $item->kategori->nama_kategori : 'null'); ?></a>
                                                    <a class="text-body" href=""><small><?php echo e($item->created_at); ?></small></a>
                                                </div>
                                                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href=""><?php echo e(Str::limit($item->judul_berita, 50, '...')); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        $smallCardCount++;
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                    </div>
                </div>
                
                
                
                <div class="col-lg-4">
                    <!-- Social Follow Start -->
                    <div class="mb-3">
                        <div class="section-title mb-0">
                            <h4 class="m-0 text-uppercase font-weight-bold">Follow Us</h4>
                        </div>
                        <div class="bg-white border border-top-0 p-3">
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #39569E;">
                                <i class="fab fa-facebook-f text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Fans</span>
                            </a>
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #52AAF4;">
                                <i class="fab fa-twitter text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Followers</span>
                            </a>
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #C8359D;">
                                <i class="fab fa-instagram text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Followers</span>
                            </a>
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #DC472E;">
                                <i class="fab fa-youtube text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Subscribers</span>
                            </a>
                        </div>
                    </div>
                    <!-- Social Follow End -->

                    <!-- Iklan kotak 800x500-->
                    <?php if (isset($component)) { $__componentOriginal998e4e40f338b69cba8e4e9ec437d134 = $component; } ?>
<?php $component = App\View\Components\Iklan800x500::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Iklan800x500'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Iklan800x500::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal998e4e40f338b69cba8e4e9ec437d134)): ?>
<?php $component = $__componentOriginal998e4e40f338b69cba8e4e9ec437d134; ?>
<?php unset($__componentOriginal998e4e40f338b69cba8e4e9ec437d134); ?>
<?php endif; ?>
                    <!-- end iklan kotak 800x500-->


                    <!-- Popular News Start -->
                    <?php if (isset($component)) { $__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb = $component; } ?>
<?php $component = App\View\Components\Popular::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('popular'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Popular::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb)): ?>
<?php $component = $__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb; ?>
<?php unset($__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb); ?>
<?php endif; ?>
                    <!-- Popular News End -->

                    <!-- Tags Start -->
                    <?php if (isset($component)) { $__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71 = $component; } ?>
<?php $component = App\View\Components\Kategori::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('kategori'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Kategori::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71)): ?>
<?php $component = $__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71; ?>
<?php unset($__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71); ?>
<?php endif; ?>
                    <!-- Tags End -->
                </div>
            </div>
        </div>
    </div><?php /**PATH E:\code\tugas-akhir\resources\views/components/news-sidebar.blade.php ENDPATH**/ ?>