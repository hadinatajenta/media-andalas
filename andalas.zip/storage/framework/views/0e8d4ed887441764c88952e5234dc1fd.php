

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div>
            <p><span style="color:blue">Dashboard</span>/ Pengaturan</p>
            <h2 class=" mb-3">Pengaturan Website</h2>
        </div>
        <div class="col-md-12">
            <div class="mt-2">
                <div >
                    <form action="<?php echo e(route('admin.pengaturan-website.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mb-3">
                            <label for="nama_website" class="form-label">Nama Website</label>
                            <input type="text" class="form-control" id="nama_website" name="nama_website" value="<?php echo e($website->nama_website ?? ''); ?>">
                        </div>
                        <div class="form-group  mb-3"">
                            <label for="deskripsi_website" class="form-label">Deskripsi Website</label>
                            <textarea class="form-control" id="deskripsi_website" name="deskripsi_website" rows="5"><?php echo e($website->deskripsi_website ?? ''); ?></textarea>
                        </div>
                        <div class="form-group  mb-3"">
                        <label for="keyword_website" class="form-label">Kata Kunci Website</label>
                        <input type="text" class="form-control" id="keyword_website" name="keyword_website" value="<?php echo e($website->keyword_website ?? ''); ?>">
                        </div>
                        <div class="form-group  mb-3"">
                        <label for="robot_txt" class="form-label">Robot.txt</label>
                        <textarea class="form-control" id="robot_txt" name="robot_txt" rows="5"><?php echo e($website->robot_txt ?? ''); ?></textarea>
                        </div>
                        <div class="form-group  mb-3"">
                        <label for="favicon" class="form-label">Favicon</label>
                        <input type="file" class="form-control" id="favicon" name="favicon">
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/settings/pengaturan-website.blade.php ENDPATH**/ ?>