

<?php $__env->startSection('title', 'Status Berita'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row align-items-center justify-content-center" >
            <!--Berita-->
            <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('admin.berita.detail', ['id' => $item->id_berita])); ?>" style="text-decoration: none; color: inherit;">
                    <div  class="row col-12 col-lg-10 my-1 align-items-center justify-content-between" style="background-color: white; border-radius: 5px; box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);">
                        <!-- Gambar dan Judul, kategori, tanggal publikasi, status -->
                        <div class="col-12 col-lg-9 p-0 d-flex align-items-center">
                            <!-- Gambar -->
                            <div class="col-lg-1">
                                <!--<img src="<?php echo e(Storage::url('berita/'.$item->gambar_berita)); ?>" class="align-items-center" style="height: 75px; width: 75px; padding: 10px; border-radius: 5px;" alt="gambar">-->
                                <img src="/images/klee.png" class="align-items-center" style="height: 75px; width: 75px; padding: 10px; border-radius: 5px;" alt="gambar">
                            </div>
                            <!-- Judul, kategori, tanggal publikasi, status -->
                            <div class="col-lg-11 mx-4 align-items-center">
                                <h6 class="m-0"><?php echo e($item->judul_berita); ?></h6>
                                <div class="row">
                                    <!-- Kategori -->
                                    <div class="col-lg-2 d-none d-lg-block">
                                        <p class="m-0"><a href="#" style="text-decoration: none;"><?php echo e($item->kategori->nama_kategori); ?></a></p>
                                    </div>
                                    <!-- Tanggal publikasi -->
                                    <div class="col-6 col-lg-4">
                                        <p class="m-0"><i class='bx bx-calendar'></i><?php echo e($item->created_at->format('d F Y')); ?></p>
                                    </div>
                                    <!-- Status -->
                                    <div class="col-lg-4 d-none d-lg-block">
                                        <p class="m-0"><span class="p-1" style="background-color:#22b07d; color:white;  border-radius:5px"><?php echo e(ucfirst($item->status)); ?></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Author & View -->
                        <div class="d-none d-lg-block col-lg-2 align-items-center">
                            <p class="m-0"><?php echo e($item->author ? $item->author->name : 'No author'); ?></p>

                            <p class="m-0">110<i class='bx bx-bar-chart'></i></p>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views//admin/berita-menunggu-persetujuan.blade.php ENDPATH**/ ?>