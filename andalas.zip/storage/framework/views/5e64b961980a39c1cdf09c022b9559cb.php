<div class="mb-3">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Advertisement</h4>
    </div>
    
    <div class="bg-white text-center border border-top-0 p-3">
        <?php if($iklan): ?>
        <a href="<?php echo e($iklan->website); ?>"><img class="img-fluid" src="/uploads/<?php echo e($iklan->gambar_iklan); ?>" alt=""></a>
        <?php else: ?>
    <p>Tidak ada iklan</p>
<?php endif; ?>
    </div>
</div>
<?php /**PATH E:\code\tugas-akhir\resources\views/components/iklan-800x500.blade.php ENDPATH**/ ?>