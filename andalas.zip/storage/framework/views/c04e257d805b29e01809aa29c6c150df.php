<!--Iklan 728x90-->
                        <div class="col-lg-12 mb-3">
                            <?php if($iklanH): ?>
                            <a href="<?php echo e($iklanH->website); ?>"><img class="img-fluid w-100" src="/uploads/<?php echo e($iklanH->gambar_iklan); ?>" alt="<?php echo e($iklanH->website); ?>"></a>
                            <?php else: ?>
                                <p>No Ads Available</p>
                            <?php endif; ?>
                        </div>   
                        <!--End Iklan--><?php /**PATH E:\code\tugas-akhir\resources\views/components/body-ads.blade.php ENDPATH**/ ?>