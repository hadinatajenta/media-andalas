

<?php $__env->startSection('title', 'Status Berita'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="d-flex justify-content-between card-header">
                        <div>
                            <h4>Daftar postingan</h4>
                            <p>postingan</p>
                        </div>
                        <div>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                                <span class="input-group-btn">
                                    <button class="btn btn-search" type="button"><i class="fa fa-search fa-fw"></i> Search</button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive" style="background-color: #fff; border-radius:10px;">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Judul Berita</th>
                                        <th scope="col">Kategori</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Author</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle" style="max-width: 250px;  overflow: hidden; text-overflow: ellipsis;">
                                            <a href="<?php echo e(route('admin.berita.detail', ['id' => $item->id_berita])); ?>"><?php echo e($item->judul_berita); ?></a>
                                        </td>
                                        <td class="align-middle"><?php echo e($item->kategori->nama_kategori ?? 'N/A'); ?></td>
                                        <td class="align-middle">
                                            <div class="p-2 d-flex align-items-center" style="border:1px solid #eaeaea; color:black; border-radius:5px; font-size:12px;">
                                                <i class='bx bxs-circle' 
                                                style="color:
                                                <?php if($item->status == 'Published'): ?>
                                                    #22b07d
                                                <?php elseif($item->status == 'waiting'): ?>
                                                    #FFC107
                                                <?php elseif($item->status == 'ditolak'): ?>
                                                    #db1731
                                                <?php elseif($item->status == 'draft'): ?>
                                                    #007bff
                                                <?php endif; ?>;">
                                                </i>
                                                &nbsp;
                                                <p class="m-0"><?php echo e($item->status); ?></p>
                                            </div>
                                        </td>
                                        <td class="align-middle"><?php echo e($item->author->name); ?></td>
                                        <td class="align-middle">
                                            <button class="btn edit-kategori" data-bs-toggle="modal" data-bs-target="#editCategoryModal<?php echo e($item->id); ?>"><i class='bx bxs-pencil'></i> &nbsp; Edit</button>
                                            <a href="/hapus/<?php echo e($item->id); ?>" class="btn hapus-kategori" onclick="return confirm('Apakah yakin akan menghapus berita ini?')"><i class='bx bx-trash' ></i></a>                                           
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views//admin/management-berita/berita-menunggu-persetujuan.blade.php ENDPATH**/ ?>