

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row my-4" >
            <div class="col">
                <div class="card p-2">
                    <div class=" d-flex align-items-center justify-content-between card-header ">
                        <div class="judul">
                            <h4>Daftar berita</h4>
                            <p class="p-0 m-0">Seluruh berita dengan semua status </p>
                        </div>
                        <form action="<?php echo e(route('author.dashboard')); ?>" method="GET" class="d-flex my-2 my-lg-0">
                            <input class="form-control mr-sm-2" type="search" placeholder="Cari Berita" aria-label="Cari Berita" name="search">
                            <button class="btn btn-outline-success my-2 my-sm-0" style="height: calc(1.5em + .75rem + 2px);" type="submit"><i class='bx bx-search-alt-2'></i></button>
                        </form>
                        <a href="<?php echo e(route('author.tambah-berita')); ?>" class="btn" style="background-color: #5a7af9; color:white; font-size:12px;">+ Tambah berita</a>

                    </div> 
                    <div class="card-body">
                        <div class="table-responsive" style="background-color: #fff; border-radius:10px;">
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php elseif(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th class="th" scope="col">Judul Berita</th>
                                        <th class="th" scope="col">Kategori</th>
                                        <th class="th" scope="col">Status</th>
                                        <th class="th" scope="col">Author</th>
                                        <th class="th" scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($berita->isEmpty()): ?>
                                        <tr>
                                            <td colspan="6" style="text-align:center">Tidak ada berita menunggu</td>
                                        </tr>
                                    <?php else: ?>
                                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle" style="max-width: 250px;  overflow: hidden; text-overflow: ellipsis;"><?php echo e($item->judul_berita); ?></td>
                                        <td class="align-middle"><?php echo e($item->kategori->nama_kategori ?? 'N/A'); ?></td>
                                        <td class="align-middle">
                                            <div class="p-2 d-flex align-items-center" style="border:1px solid #eaeaea; color:black; border-radius:5px; font-size:12px;">
                                                <i class='bx bxs-circle' 
                                                style="color:
                                                <?php if($item->status == 'Published'): ?>
                                                    #22b07d
                                                <?php elseif($item->status == 'waiting'): ?>
                                                    #FFC107
                                                <?php elseif($item->status == 'ditolak'): ?>
                                                    #db1731
                                                <?php elseif($item->status == 'draft'): ?>
                                                    #007bff
                                                <?php endif; ?>;">
                                                </i>
                                                &nbsp;
                                                <p class="m-0"><?php echo e($item->status); ?></p>
                                            </div>
                                        </td>
                                        <td class="align-middle"><?php echo e($item->author->name); ?></td>
                                        <td class="align-middle">
                                            <a href="<?php echo e(route('author.edit', $item->id_berita)); ?>" class="btn edit-kategori" >  
                                                <i class='bx bxs-pencil'></i> &nbsp; Edit
                                            </a>
                                            <form id="delete-form-<?php echo e($item->id_berita); ?>" action="<?php echo e(route('author.destroy', ['id' => $item->id_berita])); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                            <a href="<?php echo e(route('author.destroy',$item->id_berita)); ?>" class="btn hapus-kategori" onclick="
                                                    event.preventDefault();
                                                    if(confirm('Anda yakin ingin menghapus berita ini?')) {
                                                        document.getElementById('delete-form-<?php echo e($item->id_berita); ?>').submit();
                                                    }">
                                                    <i class='bx bx-trash' ></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-center mt-2">
            <?php echo e($berita->links('vendor.pagination.bootstrap-4')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAuthor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/author/dashboard.blade.php ENDPATH**/ ?>