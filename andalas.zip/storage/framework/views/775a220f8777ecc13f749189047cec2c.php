

<?php $__env->startSection('title','Pengaturan keamanan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">     
        <div class="row" style="border: 1px solid #eaeaea;">
            <!--Kiri-->
            <div class="col-md-4 p-2" style="background-color: white; color:#24252a; border:1px solid #eaeaea;">
                <div class="btn p-2">
                    <a href="/admin/pengaturan/profile" class=" d-flex my-1" style="color:#24252a; text-decoration:none; font-weight:bold;"><i class='bx bxs-edit bx-sm'></i> &nbsp; Edit profile</a>
                    <p class="text-secondary">Pengaturan informasi pribadi pengguna</p>
                </div>
                <div class="btn p-2">
                    <a href="/admin/pengaturan/keamanan" class=" d-flex my-1" style="color: #24252a; text-decoration:none; font-weight:bold;"><i class='bx bx-lock-alt bx-sm'></i>&nbsp; Keamanan</a>
                    <p class="text-secondary">Pengaturan password pengguna</p>
                </div>
            </div>

            <!--Kanan-->
            <div class="col-md-8 p-2" style="background-color: white; color:#24252a;" >
                <h4 class="p-2">Kemanan akun saya</h4>
                <form class="p-2" action="<?php echo e(route('admin.security.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="form-group mt-2 p-3" style="border: 1px solid #eaeaea; border-radius:10px">
                        <h4>Ubah Password</h4>
                        <div class="row mb-2">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="name">Password saat ini</label> 
                                    <input class="form-control" type="password" name="password"  required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="name">Password baru </label> 
                                    <input class="form-control" type="password" name="new_password" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="name">Konfirmasi Password baru </label> 
                                    <input class="form-control" type="password" name="new_password_confirmation" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/pengaturan/keamanan.blade.php ENDPATH**/ ?>