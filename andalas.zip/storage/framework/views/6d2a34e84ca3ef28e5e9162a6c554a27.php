

<?php $__env->startSection('content'); ?>
<div class="container p-4"  style="background-color: #fff; border-radius:10px;">
    <!--Tambah-->
    <div class="d-flex justify-content-between align-items-center mb-3 ">
        <h4 class="mb-0">Kategori</h4>
        <button type="button" class="btn tambah-kategori" data-bs-toggle="modal" data-bs-target="#addCategoryModal"><i class='bx bx-plus'></i>&nbsp; kategori baru</button>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <!--Modal header-->
                <div class="modal-header">
                    <h5 class="modal-title" id="addCategoryModalLabel">Tambah Kategori Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!--Modal body-->
                <div class="modal-body">
                    <form action="<?php echo e(route('kategori.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-2">
                            <label for="nama_kategori">Nama Kategori</label>
                            <input type="text" name="nama_kategori" class="form-control" id="nama_kategori" aria-describedby="nama_kategori" placeholder="Masukkan Nama Kategori">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!--List Kategori-->
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kategori</th>
                    <th scope="col" style="text-align:center">Jumlah Berita</th>
                    <th scope="col" style="text-align:center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($index + 1); ?></th>
                    <td><?php echo e($item->nama_kategori); ?></td>
                    <td style="text-align:center"><?php echo e($item->berita_count); ?></td>
                    <td style="text-align:center">
                        <button class="btn edit-kategori" data-bs-toggle="modal" data-bs-target="#editCategoryModal<?php echo e($item->id); ?>"><i class='bx bxs-pencil'></i> &nbsp; Edit</button>
                        <form action="<?php echo e(route('kategori.destroy', $item->id_kategori)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah yakin akan menghapus kategori berikut?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn hapus-kategori" type="submit"><i class='bx bx-trash' ></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Edit modals -->
    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="editCategoryModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="editCategoryModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editCategoryModalLabel<?php echo e($item->id); ?>">Edit Kategori</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('kategori.update', $item->id_kategori)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mb-2">
                            <label for="nama_kategori">Nama Kategori</label>
                            <input type="text" name="nama_kategori" class="form-control" id="nama_kategori" aria-describedby="nama_kategori" value="<?php echo e($item->nama_kategori); ?>">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/kategori.blade.php ENDPATH**/ ?>