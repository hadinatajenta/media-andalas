

<?php $__env->startSection('title','Iklan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container my-4 ">
    <div class="row">
        <div>
            <p><span style="color:blue; font-weight:bold">Dashboard</span> / Iklan</p>
            <h4>Jenis Iklan</h4>
        </div>
        <?php $__currentLoopData = $iklans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iklan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 my-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($iklan->nama_iklan); ?></h5>
                    <p class="card-text"><?php echo e($iklan->jenis_iklan); ?></p>
                    <p class="card-text">Rp <?php echo e(number_format($iklan->harga_iklan, 0, ',', '.')); ?>/ hari</p>
                   </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 my-4">
            <div class="card-body h-100 d-flex align-items-center justify-content-center" style="background-color: #91AECF; border-radius: 0.25rem">
                <a class="btn d-flex align-items-center justify-content-center" style="color: white" >
                    <i class='bx bx-plus bx-md bx-spin-hover'></i>
                    <p class="mb-0">Tambah jenis Iklan</p>
                </a>
            </div>
        </div>
    </div>
    <!-- Display advertiser information and ad addition menu -->
    <div class="row mt-2">
        <div class="col-md-8">
            <div class="card opening p-2">
                <div class="card-header d-flex justify-content-between align-items-center" style="background-color:white;color:black;">
                    <div>
                        <h1 class="h2" style="font-size: 22px">Informasi Pengiklan</h1>
                        <p style="color: #8693a0; font-size:14px;">Semua informasi pengiklan atau tambahkan pengiklan baru</p>
                    </div>
                    <a href="<?php echo e(route('admin.tambah-pengiklan')); ?>" class="btn" style="background-color: #91AECF; color:white; font-size:12px;">+ Tambah pengiklan</a>
                </div>
                <div class="card-body border-none table-responsive scrollable-table">
                    <table class="table table-hover text-nowrap">
                        <thead class="thead-dark">
                            <tr>
                                <th class="px-3">Nama Pengiklan</th>
                                <th class="px-3">Periode</th>
                                <th class="px-3">Total Harga</th>
                                <th class="px-3">Status</th>
                                <th class="px-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pengiklan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-3"><?php echo e($data->nama_pengiklan); ?></td>
                                <td class="px-3"><?php echo e(date('d M Y', strtotime($data->tanggal_masuk))); ?> - <?php echo e(date('d M Y', strtotime($data->tanggal_keluar))); ?></td>
                                <td class="px-3">Rp &nbsp;<?php echo e(number_format($data->total_harga, 2, ',', '.')); ?></td>
                                <td>
                                    <?php if($data->status == 'berjalan'): ?>
                                    <span class="badge" style="color: #007bff; border:1px solid #a6cfff; background-color:#f2f8ff; border-radius :10px">Berjalan</span>
                                    <?php elseif($data->status == 'menunggu'): ?>
                                    <span class="badge" style="color: #ffc107; border:1px solid #fff3cd; background-color:#fffdf7; border-radius :10px">Menunggu</span>
                                    <?php else: ?>
                                    <span class="badge" style="color: #28a745; border:1px solid #c3e6cb; background-color:#f2fdf7; border-radius :10px">Selesai</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-center">
                <div class="card shadow mb-4">
                    <div class="card">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Informasi Pendapatan Bulanan</h6>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('admin.iklan')); ?>">
                        <div class="form-group">
                            <label for="year">Pilih Tahun:</label>
                            <select class="form-control" name="year" id="year" onchange="this.form.submit()">
                            <?php for($y = date('Y'); $y >= 2020; $y--): ?>
                                <option value="<?php echo e($y); ?>" <?php if($y == $currentYear): ?> selected <?php endif; ?>><?php echo e($y); ?></option>
                            <?php endfor; ?>
                            </select>
                        </div>
                    </form>

                    <h3 class="card-title my-4">Tahun <?php echo e($currentYear); ?></h3>
                    <?php if(count($monthlyIncomeStats) > 0): ?>
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Bulan</th>
                                <th>Pemasukan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $monthlyIncomeStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($income->month); ?></td>
                                    <td><?php echo e($income->income); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                    <div class="alert alert-warning" role="alert">
                    Tidak ada data
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/iklan.blade.php ENDPATH**/ ?>