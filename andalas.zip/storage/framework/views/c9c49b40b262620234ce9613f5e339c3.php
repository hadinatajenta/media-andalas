<?php $__env->startComponent('mail::message'); ?>
# Selamat datang, <?php echo e($user->name); ?>


Anda telah ditambahkan sebagai author baru di website kami.
Berikut adalah informasi akun anda:
    Email : <?php echo e($user->email); ?>

    Password : <?php echo e($user->password); ?>


Terima kasih,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH E:\code\tugas-akhir\resources\views/emails/newauthor.blade.php ENDPATH**/ ?>