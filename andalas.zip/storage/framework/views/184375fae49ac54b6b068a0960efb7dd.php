<!-- resources/views/iklan/create.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Create Iklan</div>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form method="POST" id="form" action="<?php echo e(route('admin.store-pengiklan')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>         
                            <!--Nama Pengiklan-->
                            <div class="form-group">
                                <label for="nama_pengiklan">Nama Pengiklan</label>
                                <input id="nama_pengiklan" type="text" class="form-control <?php $__errorArgs = ['nama_pengiklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_pengiklan" value="<?php echo e(old('nama_pengiklan')); ?>" required autofocus>
                                <?php $__errorArgs = ['nama_pengiklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--end Nama Pengiklan-->
                            
                            <!--Jenis Iklan-->
                            <div class="form-group my-2">
                                <label for="id_iklan">Jenis Iklan</label>
                                <select id="id_iklan" class="form-control <?php $__errorArgs = ['id_iklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_iklan" required>
                                    <option value="">Pilih Jenis Iklan</option>
                                    <?php $__currentLoopData = App\Models\IklanModel::pluck('nama_iklan', 'id_iklan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $namaIklan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php echo e(old('id_iklan') == $id ? 'selected' : ''); ?>><?php echo e($namaIklan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_iklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--end Jenis Iklan-->

                            <!--Notelp Pengiklan-->
                            <div class="form-group my-1">
                                <label for="no_telp_pengiklan">No. Telp</label>
                                <input id="no_telp_pengiklan" type="text" class="form-control <?php $__errorArgs = ['no_telp_pengiklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="no_telp_pengiklan" value="<?php echo e(old('no_telp_pengiklan')); ?>" required>
                                <?php $__errorArgs = ['no_telp_pengiklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--end Notelp Pengiklan-->

                            <!--Gambar Iklan-->
                            <div class="form-group my-2">
                                <label for="gambar_iklan">Gambar Iklan</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input <?php $__errorArgs = ['gambar_iklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gambar_iklan" name="gambar_iklan"  required>
                                    <?php $__errorArgs = ['gambar_iklan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mt-3">
                                    <img id="preview" src="#" alt="your image" class="img-thumbnail" style="display: none;"/>
                                </div>
                            </div>
                            <!--End Gambar Iklan-->
          
                            <!--Alamat Website Pengiklan-->
                            <div class="form-group my-2">
                                <label for="website">Website</label>
                                <input id="website" type="url" class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="website" value="<?php echo e(old('website')); ?> " placeholder="Masukkan URL dimulai dari http:// atau https://">
                                <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--end Alamat Website Pengiklan-->

                            <!--Tanggal Masuk dan Tanggal Keluar-->
                            <div class="form-row d-flex row my-2">
                                <div class="form-group col-lg-6 my-2">
                                    <label for="tanggal_masuk">Tanggal Masuk</label>
                                    <input id="tanggal_masuk" type="date" class="form-control <?php $__errorArgs = ['tanggal_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_masuk" value="<?php echo e(old('tanggal_masuk')); ?>" required>
                                    <?php $__errorArgs = ['tanggal_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-lg-6 my-2">
                                    <label for="tanggal_keluar">Tanggal Keluar</label>
                                    <input id="tanggal_keluar" type="date" class="form-control <?php $__errorArgs = ['tanggal_keluar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_keluar" value="<?php echo e(old('tanggal_keluar')); ?>" required>
                                    <?php $__errorArgs = ['tanggal_keluar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!--end Tanggal Masuk dan Tanggal Keluar-->      
                            <div class="form-group my-2">
                                <label for="total_harga">Total Harga: </label>
                                <span id="total_harga">0</span>
                            </div>        
                            <!--Submit-->
                            <div class="form-group mb-0 my-2">
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                            </div>
                            <!--end Submit-->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $('#id_iklan, #tanggal_masuk, #tanggal_keluar').change(function() {
            let idIklan = $('#id_iklan').val();
            let tanggalMasuk = $('#tanggal_masuk').val();
            let tanggalKeluar = $('#tanggal_keluar').val();
            
            if(idIklan != "" && tanggalMasuk != "" && tanggalKeluar != ""){
                $.ajax({
                    url: '<?php echo e(route("get.harga.iklan")); ?>',
                    type: 'POST',
                    data: {
                        id_iklan: idIklan,
                        tanggal_masuk: tanggalMasuk,
                        tanggal_keluar: tanggalKeluar,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response){
                        $('#total_harga').text(response);
                    },
                    error: function (request, status, error) {
                        console.log(request.responseText);
                    }
                });
            }
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/management-iklan/tambah-pengiklan.blade.php ENDPATH**/ ?>