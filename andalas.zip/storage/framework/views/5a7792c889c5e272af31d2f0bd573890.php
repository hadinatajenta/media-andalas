

<?php $__env->startSection('content'); ?>
    <div class="align-items-center justify-content-center">
        <!--container-->
        <div class="row justify-content-evenly h-100">
            <!-- Statistik penayangan -->
            <div class="col-md-8 p-4 mb-4 h-100" style="background-color: #fff; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
                <h4 class="h4">Penayangan 7 Hari terakhir</h4>
                <div id="chart-container" style="height: 100%;">
                    <canvas id="myChart"></canvas>
                </div>
            </div>

            <!-- Author teratas -->
            <div class="col-md-3 p-4 h-100" style="background-color: #fff; border-radius:10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
                <!-- Author teratas header -->
                <div class="row mb-4">
                    <h6 class="col-9 mb-0">Author teratas</h6>
                    <a href="" class="col-3 text-right">Semua</a>
                </div>

                <!-- Author teratas body -->
                <div class="row" style="height: calc(100% - 40px);">
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 mb-3 d-flex align-items-center">
                            <img class="rounded-circle mr-2" src="/images/zhongli.png" alt="Avatar of <?php echo e($author->name); ?>" style="width: 50px; height: 50px;">
                            <span><?php echo e($author->name); ?></span>
                            <span> <?php echo e($author->berita_count); ?> posts</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($dates); ?>,
                datasets: [{
                    label: '# of Views',
                    data: <?php echo json_encode($counts); ?>,
                    backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(255, 205, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                'rgb(255, 99, 132)',
                'rgb(255, 159, 64)',
                'rgb(255, 205, 86)',
                'rgb(75, 192, 192)',
                'rgb(54, 162, 235)',
                'rgb(153, 102, 255)',
                'rgb(201, 203, 207)'
                ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\code\tugas-akhir\resources\views/admin/statistics/statistik.blade.php ENDPATH**/ ?>