                <div class="col-lg-4">
                    <!-- Social Follow Start -->
                    <div class="mb-3">
                        <div class="section-title mb-0">
                            <h4 class="m-0 text-uppercase font-weight-bold">Follow Us</h4>
                        </div>
                        <div class="bg-white border border-top-0 p-3">
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #39569E;">
                                <i class="fab fa-facebook-f text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Fans</span>
                            </a>
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #52AAF4;">
                                <i class="fab fa-twitter text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Followers</span>
                            </a>
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #C8359D;">
                                <i class="fab fa-instagram text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Followers</span>
                            </a>
                            <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #DC472E;">
                                <i class="fab fa-youtube text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Subscribers</span>
                            </a>
                        </div>
                    </div>
                    <!-- Social Follow End -->

                    <!-- Iklan kotak 800x500-->
                    <?php if (isset($component)) { $__componentOriginal998e4e40f338b69cba8e4e9ec437d134 = $component; } ?>
<?php $component = App\View\Components\Iklan800x500::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Iklan800x500'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Iklan800x500::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal998e4e40f338b69cba8e4e9ec437d134)): ?>
<?php $component = $__componentOriginal998e4e40f338b69cba8e4e9ec437d134; ?>
<?php unset($__componentOriginal998e4e40f338b69cba8e4e9ec437d134); ?>
<?php endif; ?>
                    <!-- end iklan kotak 800x500-->


                    <!-- Popular News Start -->
                    <?php if (isset($component)) { $__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb = $component; } ?>
<?php $component = App\View\Components\Popular::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('popular'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Popular::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb)): ?>
<?php $component = $__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb; ?>
<?php unset($__componentOriginalb9c4b29540d1fd0c4b8b103afaf624bb); ?>
<?php endif; ?>
                    <!-- Popular News End -->

                    <!-- Tags Start -->
                    <?php if (isset($component)) { $__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71 = $component; } ?>
<?php $component = App\View\Components\Kategori::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('kategori'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Kategori::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71)): ?>
<?php $component = $__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71; ?>
<?php unset($__componentOriginalb238b7cf40a8a3f61c6596131cfe5f71); ?>
<?php endif; ?>
                    <!-- Tags End -->
                </div><?php /**PATH E:\code\tugas-akhir\resources\views/components/sidebar.blade.php ENDPATH**/ ?>