<div class="col-lg-12 mb-3">
    <a href=""><img class="img-fluid w-100" src="/images/ads-728x90.png" alt=""></a>
</div><?php /**PATH E:\code\tugas-akhir\resources\views/components/horizontal-ads.blade.php ENDPATH**/ ?>