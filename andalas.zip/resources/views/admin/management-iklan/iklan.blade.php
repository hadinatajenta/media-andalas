@extends('layouts.app')

@section('title','Iklan')

@section('content')

<div class="container my-4 ">
    <div class="row">
        @foreach ($iklans as $iklan)
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">{{ $iklan->nama_iklan }}</h5>
                    <p class="card-text">{{ $iklan->jenis_iklan }}</p>
                    <p class="card-text">Rp {{ number_format($iklan->harga_iklan, 0, ',', '.') }}/ hari</p>
                   </div>
            </div>
        </div>
        @endforeach
        <div class="col-md-4">
            <div class="card-body h-100 d-flex align-items-center justify-content-center" style="background-color: #5a7af9; border-radius: 0.25rem">
                <a class="btn d-flex align-items-center justify-content-center" style="color: white" >
                    <i class='bx bx-pencil bx-sm'></i> &nbsp;
                    <p class="mb-0">Edit jenis Iklan</p>
                </a>
            </div>
        </div>
    </div>
    <!-- Display advertiser information and ad addition menu -->
    <div class="row mt-2">
        <div class="col-md-12 my-2">
            <div class="card opening p-2">
                <div class="card-header d-flex justify-content-between align-items-center" style="background-color:white;color:black;">
                    <div>
                        <h1 class="h2" style="font-size: 22px">Informasi Pengiklan</h1>
                        <p style="color: #8693a0; font-size:14px;">Semua informasi pengiklan atau tambahkan pengiklan baru</p>
                    </div>
                    <a href="{{ route('admin.tambah-pengiklan') }}" class="btn" style="background-color: #5a7af9; color:white; font-size:12px;">+ Tambah pengiklan</a>
                </div>
                <div class="card-body border-none table-responsive scrollable-table">
                    <table class="table table-hover text-nowrap">
                        <thead class="thead-dark">
                            <tr>
                                <th class="px-3">Nama Pengiklan</th>
                                <th class="px-3 d-flex align-items-center">
                                    Periode
                                     
                                    <div class="dropdown">
                                        <button class="btn" type="button" id="periodFilter" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class='bx bx-filter'></i>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                            <li><a class="dropdown-item" href="{{ route('admin.iklan') . '?order=asc' }}" @if($order === 'asc') selected @endif>Terbaru</a></li>
                                            <li><a class="dropdown-item" href="{{ route('admin.iklan') . '?order=desc' }}" @if($order === 'desc') selected @endif>Terlama</a></li>
                                        </ul>
                                    </div>
                                </th>

                                <th class="px-3">Total Harga</th>
                                <th class="px-3 d-flex align-items-center justify-content-between">
                                    Status
                                    <div class="dropdown">
                                        <button class="btn" type="button" id="statusFilter" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class='bx bx-filter'></i>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                            <li><a class="dropdown-item" href="{{ route('admin.iklan') . '?status=all' }}" @if($status === 'all' || !$status) selected @endif>Semua</a></li>
                                            <li><a class="dropdown-item" href="{{ route('admin.iklan') . '?status=menunggu' }}" @if($status === 'menunggu') selected @endif>Menunggu</a></li>
                                            <li><a class="dropdown-item" href="{{ route('admin.iklan') . '?status=berjalan' }}" @if($status === 'berjalan') selected @endif>Berjalan</a></li>
                                            <li><a class="dropdown-item" href="{{ route('admin.iklan') . '?status=selesai' }}" @if($status === 'selesai') selected @endif>Selesai</a></li>
                                        </ul>
                                    </div>
                                </th>

                                <th class="px-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pengiklan as $data)
                            <tr>
                                <td class="px-3">{{ $data->nama_pengiklan }}</td>
                                <td class="px-3">{{ date('d M Y', strtotime($data->tanggal_masuk)) }} - {{ date('d M Y', strtotime($data->tanggal_keluar)) }}</td>
                                <td class="px-3">Rp &nbsp;{{ number_format($data->total_harga, 2, ',', '.') }}</td>
                                <td>
                                    @if ($data->status == 'berjalan')
                                    <span class="badge" style="color: #007bff; border:1px solid #a6cfff; background-color:#f2f8ff; border-radius :10px">Berjalan</span>
                                    @elseif ($data->status == 'menunggu')
                                    <span class="badge" style="color: #ffc107; border:1px solid #fff3cd; background-color:#fffdf7; border-radius :10px">Menunggu</span>
                                    @else
                                    <span class="badge" style="color: #28a745; border:1px solid #c3e6cb; background-color:#f2fdf7; border-radius :10px">Selesai</span>
                                    @endif
                                </td>
                                <td class="px-3">
                                    <a href="{{ route('admin.edit-pengiklan', $data->id_pengiklan) }}" class="btn">
                                        <i class='bx bx-pencil'></i> 
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card text-center">
                <div class="card mb-4">
                    <div class="card">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Informasi Pendapatan Bulanan</h6>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="GET" action="{{ route('admin.iklan') }}">
                        <div class="form-group">
                            <label for="year">Pilih Tahun:</label>
                            <select class="form-control" name="year" id="year" onchange="this.form.submit()">
                            @for($y = date('Y'); $y >= 2020; $y--)
                                <option value="{{ $y }}" @if($y == $currentYear) selected @endif>{{ $y }}</option>
                            @endfor
                            </select>
                        </div>
                    </form>

                    <h3 class="card-title my-4">Tahun {{ $currentYear }}</h3>
                    @if(count($monthlyIncomeStats) > 0)
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Bulan</th>
                                <th>Pemasukan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($monthlyIncomeStats as $income)
                                <tr>
                                    <td>{{ $income->month }}</td>
                                    <td>{{ $income->income }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                    <div class="alert alert-warning" role="alert">
                    Tidak ada data
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('#periodFilter').on('change', function() {
        window.location.href = $(this).val();
    });
});

</script>

@endsection
